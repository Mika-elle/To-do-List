# Notes Android App
## Pretty simple Android application written in Kotlin to create, store and manage your notes. 
### MVVM and Architecture components are used. 
![Screenshots](https://github.com/terentyevkirill/todo-list-android-kotlin/blob/master/notes_screens.png)
