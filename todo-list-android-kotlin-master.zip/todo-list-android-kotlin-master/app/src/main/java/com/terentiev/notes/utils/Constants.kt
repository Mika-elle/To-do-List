package com.terentiev.notes.utils

object Constants {
    const val INTENT_OBJECT = "intent_object"
    const val INTENT_CREATE_NOTE = 1
    const val INTENT_UPDATE_NOTE = 2
}